import re
import json
import asyncio
import aiohttp
from typing import Callable, Optional

from core.models import (
    SubtitleEntry,
    _srt_time_to_ms,
    _format_subtitle_snapshot,
    verify_source_integrity,
)
from core.segmenter import _get_source_text, _get_target_text
from core.srt_lint import finalize_entries
from core.client import MistralClient
from core.workers import (
    LANGUAGE_MAP,
    _get_prompt_lang,
    _build_analysis_result,
    _build_analysis_messages,
    _apply_llm_merge,
    _apply_llm_split,
    _force_split_entry,
    _split_short_long,
    _translate_batch_with_repair,
    _repair_incomplete_segment_translations,
    _optimize_batch_impl,
    _translation_is_usable,
)

try:
    from ..utils import logger
except ImportError:
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from utils import logger


class SubtitlePipeline:
    """Subtitle processing pipeline.

    Accepts optional callbacks for progress, logging, and cancellation.
    Note: this module currently reuses helper functions from workers.py, so a deeper
    separation of Qt worker wrappers and pure business logic can be done later.
    """

    DEFAULT_OPTIMIZE_BATCH_TIMEOUT_SECONDS = 240

    def __init__(
        self,
        client: MistralClient,
        input_lang: str = "English",
        output_lang: str = "中文",
        concurrency: int = 12,
        batch_size: int = 5,
    ):
        self.client = client
        self.input_lang = input_lang
        self.output_lang = output_lang
        self.concurrency = concurrency
        self.batch_size = batch_size
        self.input_lang_code = LANGUAGE_MAP.get(input_lang, ("en", input_lang))[0]
        self.optimize_batch_timeout_seconds = self.DEFAULT_OPTIMIZE_BATCH_TIMEOUT_SECONDS
        self.last_lint_report = None

    # ------------------------------------------------------------------
    # Stage 1: Analyze
    # ------------------------------------------------------------------
    async def analyze(
        self,
        entries: list[SubtitleEntry],
        on_progress: Optional[Callable[[str], None]] = None,
        is_cancelled: Optional[Callable[[], bool]] = None,
    ) -> str:
        result = await self.analyze_details(entries, on_progress, is_cancelled)
        return result.context

    async def analyze_details(
        self,
        entries: list[SubtitleEntry],
        on_progress: Optional[Callable[[str], None]] = None,
        is_cancelled: Optional[Callable[[], bool]] = None,
    ):
        if is_cancelled and is_cancelled():
            raise asyncio.CancelledError()

        if on_progress:
            on_progress("正在分析字幕内容，识别翻译情景...")

        messages = _build_analysis_messages(entries, self.input_lang, self.output_lang)

        async with aiohttp.ClientSession() as session:
            raw = await self.client.chat(messages, session, temperature=0.3)

        return _build_analysis_result(raw)

    # ------------------------------------------------------------------
    # Stage 2: Segment
    # ------------------------------------------------------------------
    async def segment(
        self,
        entries: list[SubtitleEntry],
        context: str,
        glossary: str,
        on_progress: Optional[Callable[[int, int], None]] = None,
        on_log: Optional[Callable[[str], None]] = None,
        is_cancelled: Optional[Callable[[], bool]] = None,
    ) -> list[SubtitleEntry]:
        total = len(entries)
        is_native = sum(1 for e in entries if len(e.lines) == 1) > total * 0.5
        if is_native and on_log:
            on_log(f"  📋 检测到原生字幕，将自动翻译为{self.output_lang}")

        window = max(10, self.batch_size)
        batches = [entries[i:i + window] for i in range(0, total, window)]
        sem = asyncio.Semaphore(max(1, self.concurrency))
        completed = 0
        all_results: list[SubtitleEntry] = []

        async def process_batch(batch: list[SubtitleEntry]):
            nonlocal completed
            if is_cancelled and is_cancelled():
                return
            async with sem:
                if is_cancelled and is_cancelled():
                    return
                try:
                    async with aiohttp.ClientSession() as session:
                        results = await self._segment_batch(batch, context, session, on_log)
                    all_results.extend(results)
                except Exception as exc:
                    logger.warning(f"Segment batch failed: {exc}")
                    for e in batch:
                        fallback = SubtitleEntry(
                            e.index, e.start_time, e.end_time, list(e.lines))
                        fallback.source_indexes = list(e.source_indexes or [e.index])
                        all_results.append(fallback)
                finally:
                    completed += len(batch)
                    if on_progress:
                        on_progress(completed, total)

        await asyncio.gather(*[process_batch(b) for b in batches])

        # Deduplicate by index
        seen: dict[int, SubtitleEntry] = {}
        deduped: list[SubtitleEntry] = []
        duplicates: list[int] = []
        for e in all_results:
            if e.index in seen:
                duplicates.append(e.index)
                continue
            seen[e.index] = e
            deduped.append(e)

        # Sort by time, renumber
        deduped.sort(key=lambda e: _srt_time_to_ms(e.start_time))
        for i, entry in enumerate(deduped, start=1):
            entry.index = i

        # Verify source integrity
        before_words = sum(len(_get_source_text(e, self.input_lang_code).split()) for e in entries)
        after_words = sum(len(_get_source_text(e, self.input_lang_code).split()) for e in deduped)
        missing = verify_source_integrity(entries, deduped)
        status = "OK" if not missing and before_words == after_words else "FAILED"
        if on_log:
            on_log(
                f"  📊 重组完整性: {len(entries)}条/{before_words}词 → "
                f"{len(deduped)}条/{after_words}词 | "
                f"来源丢失: {sorted(missing) if missing else '无'} | "
                f"重复: {duplicates or '无'} | {status}"
            )

        logger.debug(_format_subtitle_snapshot("AFTER_SEGMENT", deduped))
        return deduped

    # ------------------------------------------------------------------
    # Stage 3: Translate
    # ------------------------------------------------------------------
    async def translate(
        self,
        entries: list[SubtitleEntry],
        context: str,
        glossary: str,
        on_progress: Optional[Callable[[int, int], None]] = None,
        on_log: Optional[Callable[[str], None]] = None,
        is_cancelled: Optional[Callable[[], bool]] = None,
    ) -> list[SubtitleEntry]:
        if self.input_lang == self.output_lang:
            if on_log:
                on_log("⏭️ 输入输出语言相同，跳过翻译，仅优化")
            return entries

        sem = asyncio.Semaphore(max(1, self.concurrency))
        total = len(entries)
        completed = 0
        CONTEXT_SIZE = 3

        starts = list(range(0, total, self.batch_size))
        batches_with_ctx: list[tuple[list[SubtitleEntry], list[SubtitleEntry], list[SubtitleEntry]]] = []
        for start in starts:
            end = min(total, start + self.batch_size)
            batch = entries[start:end]
            prev = entries[max(0, start - CONTEXT_SIZE):start]
            next_ctx = entries[end:min(total, end + CONTEXT_SIZE)]
            batches_with_ctx.append((batch, prev, next_ctx))

        async def process_batch(batch: list[SubtitleEntry], prev_ctx: list[SubtitleEntry], next_ctx: list[SubtitleEntry]):
            nonlocal completed
            if is_cancelled and is_cancelled():
                return
            async with sem:
                if is_cancelled and is_cancelled():
                    return
                try:
                    async with aiohttp.ClientSession() as session:
                        result_map, unresolved = await _translate_batch_with_repair(
                            batch, context, glossary, self.client, session,
                            self.input_lang, self.output_lang, prev_ctx, next_ctx)
                    for entry in batch:
                        translation = result_map.get(entry.index, "")
                        source_text = _get_source_text(entry, self.input_lang_code)
                        if translation and source_text:
                            entry.lines = [translation, source_text]
                            entry.status = "done"
                            entry.error_msg = ""
                        else:
                            entry.status = "error"
                            if entry.index in unresolved:
                                entry.error_msg = "translation missing after retry"
                except Exception as exc:
                    logger.error(f"Translate batch failed: {exc}")
                    for entry in batch:
                        entry.status = "error"
                        entry.error_msg = "translation batch failed"
                finally:
                    completed += len(batch)
                    if on_progress:
                        on_progress(completed, total)

        await asyncio.gather(*[process_batch(b, prev, nxt) for b, prev, nxt in batches_with_ctx])

        # Fallback: unresolved entries keep source text
        unresolved_ids = [
            entry.index for entry in entries
            if entry.status == "error" and getattr(entry, "error_msg", "").startswith("translation")
        ]
        if unresolved_ids:
            logger.warning("Translation fallback to source for ids: %s", unresolved_ids)
            unresolved_set = set(unresolved_ids)
            for entry in entries:
                if entry.index in unresolved_set:
                    source_text = _get_source_text(entry, self.input_lang_code)
                    entry.lines = [source_text] if source_text else entry.lines
                    entry.status = "needs_review"
                    entry.error_msg = "translation_failed_fallback_source"
            if on_log:
                on_log(f"    ⚠️ {len(unresolved_ids)} 条字幕翻译失败，已保留原文（ID: {unresolved_ids}）")

        # 漏译修复
        if on_log:
            on_log("  🔧 检查并修复漏译条目...")
        async with aiohttp.ClientSession() as session:
            repaired, total_incomplete = await _repair_incomplete_segment_translations(
                entries, context, glossary, self.client, session,
                self.input_lang, self.output_lang)
        if on_log:
            if total_incomplete > 0:
                on_log(f"  ✅ 漏译修复完成: {repaired}/{total_incomplete} 条已修复")
            else:
                on_log("  ✅ 漏译修复完成: 无漏译条目")

        # Final hard gate after repair: untranslated or source-only lines must not
        # be silently marked as done. They remain in the SRT for safety, but are
        # surfaced as needs_review.
        still_bad = []
        for entry in entries:
            source_text = _get_source_text(entry, self.input_lang_code)
            target_text = _get_target_text(entry, self.input_lang_code)
            if source_text and not _translation_is_usable(target_text, source_text, self.output_lang):
                entry.status = "needs_review"
                if not entry.error_msg:
                    entry.error_msg = "translation_needs_review"
                still_bad.append(entry.index)
        if still_bad and on_log:
            on_log(f"  ⚠️ 仍有 {len(still_bad)} 条未通过中文译文硬检查，已标记 needs_review: {still_bad}")

        logger.debug(_format_subtitle_snapshot("AFTER_TRANSLATE", entries))
        return entries

    # ------------------------------------------------------------------
    # Stage 4: Optimize
    # ------------------------------------------------------------------
    async def optimize(
        self,
        entries: list[SubtitleEntry],
        context: str,
        glossary: str,
        on_progress: Optional[Callable[[int, int], None]] = None,
        on_log: Optional[Callable[[str], None]] = None,
        is_cancelled: Optional[Callable[[], bool]] = None,
    ) -> list[SubtitleEntry]:
        sem = asyncio.Semaphore(max(1, self.concurrency))
        total = len(entries)
        completed = 0
        CONTEXT_SIZE = 3

        starts = list(range(0, total, self.batch_size))
        batches_with_ctx: list[tuple[list[SubtitleEntry], list[SubtitleEntry], list[SubtitleEntry]]] = []
        for start in starts:
            end = min(total, start + self.batch_size)
            batch = entries[start:end]
            prev = entries[max(0, start - CONTEXT_SIZE):start]
            next_ctx = entries[end:min(total, end + CONTEXT_SIZE)]
            batches_with_ctx.append((batch, prev, next_ctx))

        async def process_batch(batch: list[SubtitleEntry], prev_ctx: list[SubtitleEntry], next_ctx: list[SubtitleEntry]):
            nonlocal completed
            if is_cancelled and is_cancelled():
                return
            async with sem:
                if is_cancelled and is_cancelled():
                    return
                try:
                    async with aiohttp.ClientSession() as session:
                        result_map = await asyncio.wait_for(
                            _optimize_batch_impl(
                                batch, context, glossary, self.client, session,
                                self.input_lang, self.output_lang, prev_ctx, next_ctx),
                            timeout=self.optimize_batch_timeout_seconds,
                        )
                    for entry in batch:
                        if entry.index in result_map:
                            lines = result_map[entry.index]
                            entry.optimized_lines = lines
                            source_text = lines[1] if len(lines) >= 2 else _get_source_text(entry, self.input_lang_code)
                            target_text = lines[0] if lines else ""
                            if len(lines) >= 2 and _translation_is_usable(target_text, source_text, self.output_lang):
                                entry.status = "done"
                                entry.error_msg = ""
                            else:
                                entry.status = "needs_review"
                                entry.error_msg = "optimize_target_invalid"
                        else:
                            entry.status = "error"
                            entry.error_msg = "optimize result missing"
                except asyncio.TimeoutError:
                    ids = [entry.index for entry in batch]
                    logger.error(
                        "Optimize batch timed out after %ss for ids: %s",
                        self.optimize_batch_timeout_seconds,
                        ids,
                    )
                    for entry in batch:
                        entry.status = "error"
                        entry.error_msg = "optimize batch timed out"
                except Exception as exc:
                    logger.error(f"Optimize batch failed: {exc}")
                    for entry in batch:
                        entry.status = "error"
                        entry.error_msg = "optimize batch failed"
                finally:
                    completed += len(batch)
                    if on_progress:
                        on_progress(completed, total)

        await asyncio.gather(*[process_batch(b, prev, nxt) for b, prev, nxt in batches_with_ctx])

        logger.debug(_format_subtitle_snapshot("AFTER_OPTIMIZE", entries, use_optimized=True))

        # Final deterministic SRT engineering pass.  This intentionally runs
        # after LLM optimization: the model handles wording, while this pass
        # fixes mechanical subtitle issues such as tiny cues, adjacent duplicates,
        # small overlaps, and numbering.
        final_entries, lint_report = finalize_entries(
            entries,
            use_optimized=True,
            input_lang_code=self.input_lang_code,
            output_lang_code=LANGUAGE_MAP.get(self.output_lang, ("zh", self.output_lang))[0],
        )
        self.last_lint_report = lint_report
        if on_log:
            on_log(f"  ✅ {lint_report.summary()}")
            if lint_report.total_warnings:
                on_log(
                    "  ⚠️ 仍需检查："
                    f"双语结构不完整 {len(lint_report.incomplete_bilingual)}，"
                    f"高阅读压力 {len(lint_report.high_cps) + len(lint_report.bad_cps)}，"
                    f"大重叠 {len(lint_report.large_overlaps)}"
                )
        logger.debug(lint_report.to_text())
        logger.debug(_format_subtitle_snapshot("AFTER_FINAL_LINT", final_entries, use_optimized=True))
        return final_entries

    # ------------------------------------------------------------------
    # Stage 5: Final SRT lint / autofix
    # ------------------------------------------------------------------
    def finalize(
        self,
        entries: list[SubtitleEntry],
        use_optimized: bool = True,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> list[SubtitleEntry]:
        """Run the final deterministic subtitle engineering pass on demand."""
        final_entries, lint_report = finalize_entries(
            entries,
            use_optimized=use_optimized,
            input_lang_code=self.input_lang_code,
            output_lang_code=LANGUAGE_MAP.get(self.output_lang, ("zh", self.output_lang))[0],
        )
        self.last_lint_report = lint_report
        if on_log:
            on_log(f"  ✅ {lint_report.summary()}")
        return final_entries

    def get_last_lint_report_text(self) -> str:
        if not self.last_lint_report:
            return ""
        return self.last_lint_report.to_text()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------
    async def _segment_batch(
        self,
        batch: list[SubtitleEntry],
        context: str,
        session: aiohttp.ClientSession,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> list[SubtitleEntry]:
        """LLM merge + split for one batch."""
        batch = await self._llm_merge(batch, context, session, on_log)

        short_entries, long_entries = _split_short_long(batch, lang_code=self.input_lang_code)
        if not long_entries:
            return short_entries

        split_results = await self._split_long_entries_with_llm(
            long_entries, context, session, on_log)
        return short_entries + split_results

    def _build_split_messages(
        self,
        entries: list[SubtitleEntry],
        context: str,
    ) -> list[dict]:
        items_json = json.dumps([
            {"id": e.index, "en": _get_source_text(e, self.input_lang_code),
             "start": e.start_time, "end": e.end_time}
            for e in entries
        ], ensure_ascii=False)

        lang_name = _get_prompt_lang(self.input_lang)
        sys_content = (
            "你是专业字幕切分助手。\n"
            f"【背景与风格】\n{context}\n\n"
            f"任务：以下{lang_name}字幕条目过长（>20词），找出所有自然断点，"
            f"按需切分，确保每段 ≤20词，不限制段数。\n\n"
            "规则：\n"
            "1. 每段 ≤20个词，包括最后一段\n"
            "2. 断点选在最自然的语义边界：从句结束、意群转折、自然停顿处\n"
            "3. 每段必须是相对完整的语义单元（不可在词组内部切断）\n"
            "4. 只返回断点的词序号，不要输出任何正文内容\n"
            "5. 严格按JSON格式返回，不要加任何解释\n\n"
            "【重要】返回格式：\n"
            '[{"id": 原id, "break_after_word": [n1, n2, ...]}]\n'
            "break_after_word 是断点列表，值为词序号（从1开始计数），表示在第n个词之后断开。\n"
            '无需切分时返回空列表：[{"id": 原id, "break_after_word": []}]\n\n'
            "示例：原文共50词，在第15词后、第30词后、第45词后各断一次：\n"
            '[{"id": 6, "break_after_word": [15, 30, 45]}]'
        )

        messages = [
            {"role": "system", "content": sys_content},
            {"role": "user", "content": f"切分以下长字幕条目：\n{items_json}"}
        ]
        return messages

    async def _split_long_entries_with_llm(
        self,
        long_entries: list[SubtitleEntry],
        context: str,
        session: aiohttp.ClientSession,
        on_log: Optional[Callable[[str], None]] = None,
        max_rounds: int = 3,
    ) -> list[SubtitleEntry]:
        finished: list[SubtitleEntry] = []
        pending = list(long_entries)

        for round_idx in range(max_rounds):
            if not pending:
                break

            try:
                response = await self.client.chat(
                    self._build_split_messages(pending, context),
                    session,
                    temperature=0.2,
                )
                clean = re.sub(r'```(?:json)?|```', '', response).strip()
                data = json.loads(clean)
                round_results = _apply_llm_split(
                    pending,
                    data,
                    log_fn=on_log,
                    lang_code=self.input_lang_code,
                    fallback_to_local=False,
                )
            except Exception as exc:
                logger.warning(f"LLM split round {round_idx + 1} failed: {exc}")
                break

            short_entries, pending = _split_short_long(
                round_results,
                lang_code=self.input_lang_code,
            )
            finished.extend(short_entries)

            if pending and on_log:
                on_log(
                    f"  LLM切分第 {round_idx + 1} 轮后仍有 "
                    f"{len(pending)} 条过长，继续请求切分"
                )

        if pending:
            if on_log:
                on_log(f"  LLM切分仍有 {len(pending)} 条过长，使用本地兜底切分")
            for entry in pending:
                finished.extend(
                    _force_split_entry(
                        entry,
                        lang_code=self.input_lang_code,
                        log_fn=on_log,
                    )
                )

        finished.sort(key=lambda e: _srt_time_to_ms(e.start_time))
        return finished

    async def _llm_merge(
        self,
        batch: list[SubtitleEntry],
        context: str,
        session: aiohttp.ClientSession,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> list[SubtitleEntry]:
        """LLM merge pass: merge semantically incomplete adjacent entries."""
        if not batch:
            return batch

        lang_name = _get_prompt_lang(self.input_lang)
        items_json = json.dumps([
            {"id": e.index, "text": _get_source_text(e, self.input_lang_code)}
            for e in batch
        ], ensure_ascii=False)

        sys_content = (
            f"你是专业字幕合并助手。\n"
            f"【背景与风格】\n{context}\n\n"
            f"任务：以下{lang_name}字幕条目按时间顺序排列，部分条目是不完整的半句，"
            f"需要将语义上属于同一句的相邻条目合并为一组。\n\n"
            "规则：\n"
            "1. 以逗号、连词、介词、助词等结尾的条目必须与后续条目合并，直到语义完整\n"
            "2. 每组合并后的词数不超过25词（中文不超过40字）\n"
            "3. 已经是完整句子的条目单独一组，ids列表只含自身id\n"
            "4. 必须覆盖所有输入条目，不得遗漏任何id\n"
            "5. 严格按JSON格式返回，不要加任何解释\n"
            "6. 【语气词/插话处理】Okay./Sure./Right./Alright./Yeah./Uh-huh./Mm. 等单词短句"
            "不视为独立完整句，必须并入相邻条目：若前一组语义未完整则并入前一组，"
            "若前一组已完整则并入后一组\n"
            "7. 【半句识别】原文以 'the'/'a'/'an'/'of'/'to'/'and'/'but'/'or'/'that'/'which'/"
            "'with'/'in'/'on'/'at'/'is'/'are'/'was'/'were' 等词结尾，"
            "必定是半句，强制与下一条合并\n\n"
            "【重要】返回格式：\n"
            '[{"ids": [id1, id2, ...]}, ...]\n'
            "每个对象的ids是需要合并的相邻条目id列表，按原顺序排列。\n\n"
            "示例1：条目3以逗号结尾，条目4是它的后半句，条目5是完整句：\n"
            '[{"ids": [3, 4]}, {"ids": [5]}]\n\n'
            '示例2：条目6是完整句，条目7是"Okay."，条目8是新句的开头：\n'
            '[{"ids": [6]}, {"ids": [7, 8]}]'
        )

        messages = [
            {"role": "system", "content": sys_content},
            {"role": "user", "content": f"分析并合并以下字幕条目：\n{items_json}"}
        ]

        try:
            response = await self.client.chat(messages, session, temperature=0.2)
            clean = re.sub(r'```(?:json)?|```', '', response).strip()
            data = json.loads(clean)
            return _apply_llm_merge(batch, data, log_fn=on_log, lang_code=self.input_lang_code)
        except Exception as exc:
            logger.warning(f"LLM merge pass failed, keeping original batch: {exc}")
            return batch
