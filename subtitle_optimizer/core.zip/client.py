from pathlib import Path
import asyncio
import json

import aiohttp

from core.transcription import get_content_type


RETRYABLE_TRANSCRIPTION_STATUS_CODES = {408, 429, 500, 502, 503, 504}


def _emit_log(on_log, message: str):
    logger.info(message)
    if on_log:
        on_log(message)


def _transcription_result_is_empty(result: dict) -> bool:
    segments = result.get("segments") or []
    text = str(result.get("text") or "").strip()
    return not segments and not text


class _RetryableTranscriptionError(RuntimeError):
    pass


def _redact_headers(headers: dict) -> dict:
    redacted = dict(headers)
    if "Authorization" in redacted:
        redacted["Authorization"] = "Bearer ***"
    return redacted


def _format_api_error(status: int, text: str, *, limit: int = 4000) -> str:
    raw = (text or "").strip()
    if not raw:
        return f"API错误 {status}: <empty response body>"

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return f"API错误 {status}: {raw[:limit]}"

    if not isinstance(data, dict):
        return f"API错误 {status}: {raw[:limit]}"

    parts = [f"API错误 {status}"]
    if data.get("error"):
        parts.append(f"error={data['error']}")
    if data.get("last_error"):
        parts.append(f"last_error={data['last_error']}")

    details = data.get("details")
    if isinstance(details, list) and details:
        rendered = []
        for item in details[:5]:
            if not isinstance(item, dict):
                rendered.append(str(item))
                continue
            fields = []
            for key in ("node", "attempt", "max_retries", "endpoint", "type", "message", "status_code", "request_id", "hint"):
                if item.get(key) is not None:
                    fields.append(f"{key}={item[key]}")
            if item.get("body"):
                fields.append(f"body={str(item['body'])[:1200]}")
            rendered.append("; ".join(fields))
        parts.append("details=[" + " | ".join(rendered) + "]")
    elif isinstance(details, str) and details:
        parts.append(f"details={details[:limit]}")

    if len(parts) == 1:
        parts.append(raw[:limit])
    return ": ".join(parts[:2]) if len(parts) == 2 else " | ".join(parts)

# 尝试相对导入，如果失败则使用绝对导入
try:
    from ..utils import logger
except ImportError:
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from utils import logger


class MistralClient:
    DEFAULT_BASE = "https://api.mistral.ai/v1"
    DEFAULT_CHAT_TEMPERATURE = 0.1

    def __init__(self, api_key: str, model: str = "mistral-large-latest",
                 base_url: str = "", transcription_model: str = "",
                 default_chat_temperature: float = DEFAULT_CHAT_TEMPERATURE):
        self.api_key = api_key
        self.model = model
        self.default_chat_temperature = default_chat_temperature
        self.transcription_model = transcription_model.strip() or model
        base = base_url.strip().rstrip("/") if base_url.strip() else self.DEFAULT_BASE
        self.base_url = base
        self.chat_url = f"{base}/chat/completions"
        self.transcription_url = f"{base}/audio/transcriptions"
        logger.debug(f"MistralClient初始化完成，模型: {model}")

    async def chat(
        self,
        messages: list[dict],
        session: aiohttp.ClientSession,
        extra_payload: dict | None = None,
        temperature: float | None = None,
    ) -> str:
        logger.debug(f"开始与Mistral API通信，消息数量: {len(messages)}")
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.default_chat_temperature if temperature is None else temperature,
        }
        if extra_payload:
            payload.update(extra_payload)

        logger.info(f"发送API请求到: {self.chat_url}，模型: {self.model}")
        try:
            async with session.post(self.chat_url, headers=headers, json=payload) as resp:
                logger.debug(f"API响应状态码: {resp.status}")
                if resp.status != 200:
                    text = await resp.text()
                    error_msg = _format_api_error(resp.status, text)
                    logger.error(error_msg)
                    logger.error(f"请求URL: {self.chat_url}")
                    logger.error(f"请求头: {_redact_headers(headers)}")
                    logger.error(f"请求负载: {payload}")
                    raise RuntimeError(error_msg)
                data = await resp.json()
                logger.info(f"成功收到API响应，状态码: {resp.status}")
                content = data["choices"][0]["message"]["content"]
                # content 偶尔以列表形式返回（多模态/thinking格式），统一提取为纯文本
                if isinstance(content, list):
                    content = "\n".join(
                        item.get("text", "") if isinstance(item, dict) else str(item)
                        for item in content
                    ).strip()
                return content
        except Exception as e:
            logger.error(f"Mistral API调用失败: {str(e)}")
            logger.error(f"请求URL: {self.chat_url}")
            raise

    async def transcribe_audio(self, audio_path: str, model: str = None,
                               language: str = None, max_retries: int = 3,
                               retry_delay_seconds: float = 3.0,
                               on_log=None) -> dict:
        request_count = max(1, int(max_retries or 1))
        retry_delay = max(0.0, float(retry_delay_seconds or 0.0))
        _emit_log(
            on_log,
            f"Starting transcription API request sequence "
            f"(max attempts: {request_count}, retry delay: {retry_delay:g}s)",
        )

        retryable_errors: list[str] = []

        for request_id in range(1, request_count + 1):
            try:
                result = await self._transcribe_audio_once(
                    audio_path,
                    request_id=request_id,
                    request_count=request_count,
                    model=model,
                    language=language,
                    on_log=on_log,
                )
            except _RetryableTranscriptionError as exc:
                retryable_errors.append(str(exc))
                _emit_log(
                    on_log,
                    f"Transcription API request {request_id}/{request_count} failed: {exc}",
                )
                if request_id < request_count and retry_delay:
                    await asyncio.sleep(retry_delay)
                continue

            if _transcription_result_is_empty(result):
                _emit_log(
                    on_log,
                    f"Transcription API request {request_id}/{request_count} returned empty transcript; using empty result",
                )
            else:
                _emit_log(
                    on_log,
                    f"Transcription API request {request_id}/{request_count} returned usable transcript; using it",
                )
            return result

        detail = "; ".join(retryable_errors) if retryable_errors else "all requests failed"
        raise RuntimeError(
            f"Transcription API request failed after {request_count} attempts: {detail}"
        )

    async def _transcribe_audio_once(self, audio_path: str, request_id: int,
                                     request_count: int, model: str = None,
                                     language: str = None, on_log=None,
                                     started_event: asyncio.Event | None = None) -> dict:
        _emit_log(
            on_log,
            f"Transcription API request {request_id}/{request_count} starting: "
            f"{Path(audio_path).name}",
        )

        headers = {"Authorization": f"Bearer {self.api_key}"}
        data = aiohttp.FormData()
        data.add_field("model", model or self.transcription_model)
        data.add_field("timestamp_granularities", "segment")
        data.add_field("diarize", "true")
        if language:
            data.add_field("language", language)

        try:
            with open(audio_path, "rb") as f:
                data.add_field(
                    "file",
                    f,
                    filename=Path(audio_path).name,
                    content_type=get_content_type(audio_path),
                )
                timeout = aiohttp.ClientTimeout(total=900)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    _emit_log(
                        on_log,
                        f"Transcription API request {request_id}/{request_count} POST sent: "
                        f"{self.transcription_url}",
                    )
                    if started_event and not started_event.is_set():
                        started_event.set()
                    async with session.post(self.transcription_url, headers=headers, data=data) as resp:
                        _emit_log(
                            on_log,
                            f"Transcription API request {request_id}/{request_count} response status: {resp.status}",
                        )
                        if resp.status != 200:
                            text = await resp.text()
                            error_msg = _format_api_error(resp.status, text)
                            logger.error(error_msg)
                            logger.error(f"Transcription request URL: {self.transcription_url}")
                            if resp.status in RETRYABLE_TRANSCRIPTION_STATUS_CODES:
                                raise _RetryableTranscriptionError(error_msg)
                            raise RuntimeError(error_msg)
                        return await resp.json()
        except (asyncio.TimeoutError, aiohttp.ClientError) as exc:
            if started_event and not started_event.is_set():
                started_event.set()
            raise _RetryableTranscriptionError(str(exc)) from exc
        except Exception:
            if started_event and not started_event.is_set():
                started_event.set()
            raise
